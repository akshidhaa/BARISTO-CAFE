import 'package:flutter/material.dart';

class UpiPage extends StatelessWidget {
  const UpiPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("UPI Payment")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Text("Scan QR and Enter Transaction ID",
                style: TextStyle(fontSize: 18)),
            const SizedBox(height: 20),
            Image.asset("assets/qr.jpg", height: 200),
            const SizedBox(height: 20),
            const TextField(
              decoration: InputDecoration(
                labelText: "Transaction ID",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pushNamed(context, "/receipt"),
              child: const Text("Verify Payment"),
            ),
          ],
        ),
      ),
    );
  }
}
