import 'package:flutter/material.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.brown[50],
      body: Stack(
        children: [
          /// TOP LEFT IMAGE
          Positioned(
            top: 60,
            left: 20,
            child: Container(
              width: 140,
              height: 140,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                image: const DecorationImage(
                  image: AssetImage("assets/cafe1.jpg"),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),

          /// TOP RIGHT IMAGE
          Positioned(
            top: 60,
            right: 20,
            child: Container(
              width: 140,
              height: 140,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                image: const DecorationImage(
                  image: AssetImage("assets/cof.jpg"),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),

          /// BOTTOM LEFT IMAGE
          Positioned(
            bottom: 140,
            left: 20,
            child: Container(
              width: 140,
              height: 140,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                image: const DecorationImage(
                  image: AssetImage("assets/cafe3.jpg"),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),

          /// BOTTOM RIGHT IMAGE
          Positioned(
            bottom: 140,
            right: 20,
            child: Container(
              width: 140,
              height: 140,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                image: const DecorationImage(
                  image: AssetImage("assets/cafe4.jpg"),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),

          /// CENTER CONTENT
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    "BARISTO CAFE",
                    style: TextStyle(
                      fontSize: 38,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 3,
                      color: Colors.brown,
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "Coffee is a language in itself.\n"
                    "Every cup tells a story of warmth\n"
                    "and conversation.",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16),
                  ),
                  const SizedBox(height: 15),
                  const Text(
                    "Experience the aroma of freshly brewed coffee\n"
                    "and the cozy ambience of Baristo Cafe.",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 15),
                  ),
                  const SizedBox(height: 30),

                  // LOGIN / SIGNUP OPTIONS
                  const Text("Already a part of our family?"),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.brown),
                    onPressed: () => Navigator.pushNamed(context, "/login"),
                    child: const Text("LOGIN"),
                  ),
                  const SizedBox(height: 20),
                  const Text("Want to join us?"),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.brown),
                    onPressed: () => Navigator.pushNamed(context, "/signup"),
                    child: const Text("SIGNUP"),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

