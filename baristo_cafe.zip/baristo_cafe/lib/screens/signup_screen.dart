import 'package:flutter/material.dart';

class SignupScreen extends StatelessWidget {
  const SignupScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Signup")),
      body: Center(
        child: Container(
          width: 320,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.brown),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text("Register", style: TextStyle(fontSize:22)),
              const TextField(decoration: InputDecoration(labelText: "Name")),
              const TextField(decoration: InputDecoration(labelText: "Username")),
              const TextField(decoration: InputDecoration(labelText: "DOB")),
              const TextField(decoration: InputDecoration(labelText: "Mobile Number")),
              const TextField(decoration: InputDecoration(labelText: "Password"), obscureText: true),
              const SizedBox(height:20),
              ElevatedButton(
                onPressed: (){
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Registered Successfully"))
                  );
                  Navigator.pushNamed(context, "/login");
                },
                child: const Text("REGISTER"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
