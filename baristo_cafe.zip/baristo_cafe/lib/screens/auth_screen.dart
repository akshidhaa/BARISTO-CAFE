import 'package:flutter/material.dart';
import 'login_screen.dart';
import 'signup_screen.dart';

class AuthScreen extends StatelessWidget {
  const AuthScreen({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: const Text("Baristo Cafe ☕"),
        centerTitle: true,
      ),

      body: Center(

        child: Padding(
          padding: const EdgeInsets.all(20),

          child: Column(

            mainAxisAlignment: MainAxisAlignment.center,

            children: [

              const Text(
                "Welcome Customer ☕",
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: Colors.brown,
                ),
              ),

              const SizedBox(height: 40),

              /// LOGIN BUTTON
              SizedBox(
                width: 200,
                child: ElevatedButton(

                  onPressed: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context)=> const LoginScreen()),
                    );
                  },

                  child: const Text("LOGIN"),
                ),
              ),

              const SizedBox(height: 20),

              /// SIGNUP BUTTON
              SizedBox(
                width: 200,
                child: ElevatedButton(

                  onPressed: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context)=> const SignupScreen()),
                    );
                  },

                  child: const Text("SIGNUP"),
                ),
              ),

              const SizedBox(height: 30),

              const Text(
                "New Customer? Please Sign Up\nAlready part of our cafe family? Login",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16),
              ),
            ],
          ),
        ),
      ),
    );
  }
}