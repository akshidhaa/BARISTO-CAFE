import 'package:flutter/material.dart';

class PaymentScreen extends StatelessWidget {
  const PaymentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>? ?? {};
    final items = args["items"] as Map<String, int>? ?? {};
    final total = args["total"] ?? 0;

    return Scaffold(
      appBar: AppBar(title: const Text("Payment Options")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            ListTile(
              leading: const Icon(Icons.qr_code, color: Colors.green),
              title: const Text("UPI Payment"),
              onTap: () {
                Navigator.pushNamed(context, "/upi",
                    arguments: {"items": items, "total": total, "method": "UPI"});
              },
            ),
            ListTile(
              leading: const Icon(Icons.credit_card, color: Colors.blue),
              title: const Text("Card Payment"),
              onTap: () {
                Navigator.pushNamed(context, "/card",
                    arguments: {"items": items, "total": total, "method": "Card"});
              },
            ),
            ListTile(
              leading: const Icon(Icons.money, color: Colors.brown),
              title: const Text("Cash Payment"),
              onTap: () {
                Navigator.pushNamed(context, "/cash",
                    arguments: {"items": items, "total": total, "method": "Cash"});
              },
            ),
          ],
        ),
      ),
    );
  }
}

