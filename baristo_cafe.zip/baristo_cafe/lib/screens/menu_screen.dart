import 'package:flutter/material.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  String selectedCategory = "ALL";

  List<Map<String, dynamic>> allItems = [
    {"name":"Cappuccino","image":"assets/cappuccino.jpg","price":180,"cat":"BEVERAGES"},
    {"name":"Latte","image":"assets/latte.jpg","price":200,"cat":"BEVERAGES"},
    {"name":"Espresso","image":"assets/espresso.jpg","price":150,"cat":"BEVERAGES"},
    {"name":"Frappe","image":"assets/frappe.jpg","price":220,"cat":"BEVERAGES"},
    {"name":"Tea","image":"assets/tea.jpg","price":120,"cat":"BEVERAGES"},
    {"name":"Matcha","image":"assets/matcha.jpg","price":240,"cat":"BEVERAGES"},
    {"name":"Momos","image":"assets/momos.jpg","price":140,"cat":"SNACKS"},
    {"name":"Pizza","image":"assets/pizza.jpg","price":260,"cat":"SNACKS"},
    {"name":"Fries","image":"assets/fries.jpg","price":130,"cat":"SNACKS"},
    {"name":"Lava Cake","image":"assets/lavacake.jpg","price":180,"cat":"DESSERTS"},
    {"name":"Mango Dessert","image":"assets/mango.jpg","price":200,"cat":"DESSERTS"},
    {"name":"Choco Mousse","image":"assets/choco.jpg","price":210,"cat":"DESSERTS"},
    {"name":"Choco Truffle","image":"assets/chocotruffle.jpg","price":220,"cat":"DESSERTS"},
    {"name":"Biscoff Cheesecake","image":"assets/biscoff.jpg","price":300,"cat":"DESSERTS"},
    {"name":"Mojito","image":"assets/mojito.jpg","price":160,"cat":"DRINKS"},
    {"name":"Lemonade","image":"assets/lemonade.jpg","price":140,"cat":"DRINKS"},
  ];

  Map<String,int> cart = {};

  // CATEGORY BUTTON
  Widget categoryButton(String name){
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal:5),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: selectedCategory==name ? Colors.brown : Colors.grey[300],
        ),
        onPressed: (){
          setState(() {
            selectedCategory = name;
          });
        },
        child: Text(
          name,
          style: TextStyle(
            color:selectedCategory==name ? Colors.white : Colors.black
          ),
        ),
      ),
    );
  }

  // CATEGORY MESSAGE
  String getCategoryLine(){
    switch(selectedCategory){
      case "BEVERAGES": return "Tired? ☕ Take a sip and recharge.";
      case "SNACKS": return "Hungry? 🍟 Grab a crunchy bite.";
      case "DESSERTS": return "Life is short 🍰 Eat dessert first.";
      case "DRINKS": return "Chill out 🧊 Refresh with cool drinks.";
      default: return "Welcome to Baristo Cafe ☕ Enjoy our delicious menu.";
    }
  }

  @override
  Widget build(BuildContext context) {
    List filtered = selectedCategory=="ALL"
        ? allItems
        : allItems.where((i)=>i["cat"]==selectedCategory).toList();

    return Scaffold(
      appBar: AppBar(title: const Text("Baristo Cafe Menu ☕")),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height:15),
            const Text(
              "WELCOME",
              style: TextStyle(
                fontSize:28,
                fontWeight:FontWeight.bold,
                color:Colors.brown
              ),
            ),
            const SizedBox(height:8),
            Text(getCategoryLine(),
              style: const TextStyle(fontSize:16),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height:20),

            // CATEGORY BUTTONS
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  categoryButton("ALL"),
                  categoryButton("BEVERAGES"),
                  categoryButton("SNACKS"),
                  categoryButton("DESSERTS"),
                  categoryButton("DRINKS"),
                ],
              ),
            ),

            const SizedBox(height:20),

            // GRID MENU
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: filtered.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio:0.75,
                crossAxisSpacing:10,
                mainAxisSpacing:10
              ),
              itemBuilder:(context,index){
                var item = filtered[index];
                cart.putIfAbsent(item["name"], () => 0);

                return Card(
                  elevation:4,
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Column(
                      children: [
                        Image.asset(item["image"], height:110, fit:BoxFit.contain),
                        const SizedBox(height:10),
                        Text(item["name"], style:const TextStyle(fontWeight:FontWeight.bold)),
                        Text("₹${item["price"]}"),
                        const SizedBox(height:5),
                        Row(
                          mainAxisAlignment:MainAxisAlignment.center,
                          children:[
                            IconButton(
                              icon:const Icon(Icons.remove),
                              onPressed:(){
                                if(cart[item["name"]]!>0){
                                  setState(() {
                                    cart[item["name"]] = cart[item["name"]]! - 1; // FIXED
                                  });
                                }
                              },
                            ),
                            Text("${cart[item["name"]]}"),
                            IconButton(
                              icon:const Icon(Icons.add),
                              onPressed:(){
                                if(cart[item["name"]]!<5){
                                  setState(() {
                                    cart[item["name"]] = cart[item["name"]]! + 1;
                                  });
                                }
                              },
                            ),
                          ],
                        ),
                        ElevatedButton(
                          onPressed: cart[item["name"]]==0 ? null : (){
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text("${item["name"]} added to cart")),
                            );
                          },
                          child: const Text("Add To Cart"),
                        )
                      ],
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height:30),

            // VIEW CART BUTTON
            ElevatedButton(
              style:ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal:40,vertical:15)
              ),
              onPressed: (){
                Map<String,int> selectedItems = {};
                cart.forEach((key,value){
                  if(value>0){
                    selectedItems[key] = value;
                  }
                });
                if(selectedItems.isEmpty){
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Cart is Empty")),
                  );
                  return;
                }
                Navigator.pushNamed(context, "/cart", arguments: selectedItems);
              },
              child:const Text("View Cart"),
            ),

            const SizedBox(height:30)
          ],
        ),
      ),
    );
  }
}
