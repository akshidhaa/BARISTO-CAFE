import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class BillPage extends StatelessWidget {
  const BillPage({super.key});

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>? ?? {};
    final items = args["items"] as Map<String, int>? ?? {};
    final total = args["total"] ?? 0;
    final method = args["method"] ?? "Unknown";

    final now = DateTime.now();
    final formattedDate = DateFormat('dd-MM-yyyy').format(now);
    final formattedTime = DateFormat('hh:mm a').format(now);

    return Scaffold(
      appBar: AppBar(title: const Text("Bill")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Text("BARISTO CAFE",
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.brown)),
            const SizedBox(height: 10),
            Text("Date: $formattedDate   Time: $formattedTime"),
            const Divider(height: 30, thickness: 2),

            Expanded(
              child: ListView(
                children: items.entries.map((entry) {
                  return ListTile(
                    title: Text(entry.key),
                    trailing: Text("Qty: ${entry.value}"),
                  );
                }).toList(),
              ),
            ),

            const Divider(height: 30, thickness: 2),
            Text("Total Amount: ₹$total",
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text("Payment Done By Method: $method"),

            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Bill downloaded successfully")),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.brown),
              child: const Text("DOWNLOAD BILL"),
            ),

            const SizedBox(height: 30),
            const Text("THANK YOU\nENJOY YOUR DAY WITH A SMILE 😊",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}
