import 'package:flutter/material.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Login")),
      body: Center(
        child: Container(
          width: 320,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.brown),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text("Login", style: TextStyle(fontSize:22,fontWeight: FontWeight.bold)),
              const SizedBox(height:20),
              const TextField(decoration: InputDecoration(labelText: "Name")),
              const TextField(decoration: InputDecoration(labelText: "Username")),
              const TextField(decoration: InputDecoration(labelText: "Mobile Number"), keyboardType: TextInputType.phone),
              const TextField(decoration: InputDecoration(labelText: "Password"), obscureText: true),
              const SizedBox(height:20),
              ElevatedButton(
                onPressed: () => Navigator.pushNamed(context, "/menu"),
                child: const Text("LOGIN"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
