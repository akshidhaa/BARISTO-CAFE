import 'package:flutter/material.dart';

class CardPage extends StatelessWidget {
  const CardPage({super.key});

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>? ?? {};

    return Scaffold(
      appBar: AppBar(title: const Text("Card Payment")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const TextField(decoration: InputDecoration(labelText: "Card Holder Name")),
            const TextField(decoration: InputDecoration(labelText: "Expiry Date")),
            const TextField(
              decoration: InputDecoration(labelText: "CVV"),
              obscureText: true,
              keyboardType: TextInputType.number,
            ),
            const TextField(
              decoration: InputDecoration(labelText: "Mobile Number"),
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, "/receipt", arguments: args);
              },
              child: const Text("Confirm Payment"),
            ),
          ],
        ),
      ),
    );
  }
}
