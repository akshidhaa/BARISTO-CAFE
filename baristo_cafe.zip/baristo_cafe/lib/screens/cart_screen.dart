import 'package:flutter/material.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  int getPrice(String item) {
    const prices = {
      "Cappuccino": 180,
      "Latte": 200,
      "Espresso": 150,
      "Frappe": 220,
      "Tea": 120,
      "Matcha": 240,
      "Momos": 140,
      "Pizza": 260,
      "Fries": 130,
      "Lava Cake": 180,
      "Mango Dessert": 200,
      "Choco Mousse": 210,
      "Choco Truffle": 220,
      "Biscoff Cheesecake": 300,
      "Mojito": 160,
      "Lemonade": 140,
    };
    return prices[item] ?? 0;
  }

  @override
  Widget build(BuildContext context) {
    final cartItems =
        ModalRoute.of(context)?.settings.arguments as Map<String, int>? ?? {};

    int total = 0;
    cartItems.forEach((item, qty) {
      total += getPrice(item) * qty;
    });

    return Scaffold(
      appBar: AppBar(title: const Text("Your Cart 🛒")),
      body: cartItems.isEmpty
          ? const Center(child: Text("Your Cart is Empty", style: TextStyle(fontSize: 22)))
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: cartItems.length,
                    itemBuilder: (context, index) {
                      String itemName = cartItems.keys.elementAt(index);
                      int qty = cartItems[itemName]!;
                      int price = getPrice(itemName);
                      return ListTile(
                        leading: const Icon(Icons.fastfood, color: Colors.brown),
                        title: Text(itemName, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text("₹$price each"),
                        trailing: Text("Qty: $qty"),
                      );
                    },
                  ),
                ),
                const Divider(),
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text("Total Amount: ₹$total",
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(
                      context,
                      "/payment",
                      arguments: {"items": cartItems, "total": total},
                    );
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.brown),
                  child: const Text("PROCEED TO PAYMENT"),
                ),
              ],
            ),
    );
  }
}
