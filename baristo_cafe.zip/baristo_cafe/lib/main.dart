import 'package:flutter/material.dart';
import 'screens/welcome_screen.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/menu_screen.dart';
import 'screens/cart_screen.dart';
import 'screens/payment_screen.dart';
import 'screens/upi_page.dart';
import 'screens/card_page.dart';
import 'screens/cash_page.dart';
import 'screens/receipt_page.dart';
import 'screens/bill_page.dart';   // <-- add this import

void main() {
  runApp(const BaristoCafe());
}

class BaristoCafe extends StatelessWidget {
  const BaristoCafe({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Baristo Cafe",
      theme: ThemeData(primarySwatch: Colors.brown),
      home: const WelcomeScreen(),
      routes: {
        "/login": (context) => const LoginScreen(),
        "/signup": (context) => const SignupScreen(),
        "/menu": (context) => const MenuScreen(),
        "/cart": (context) => const CartScreen(),
        "/payment": (context) => const PaymentScreen(),
        "/upi": (context) => const UpiPage(),
        "/card": (context) => const CardPage(),
        "/cash": (context) => const CashPage(),
        "/receipt": (context) => const ReceiptPage(),
        "/bill": (context) => const BillPage(),   // <-- register BillPage route
      },
    );
  }
}
