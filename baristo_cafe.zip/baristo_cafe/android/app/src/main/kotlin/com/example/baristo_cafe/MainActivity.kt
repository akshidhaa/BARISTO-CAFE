package com.example.baristo_cafe

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
